/**
 * New node file
 */
 console.log("install success");

process.on('exit',function(err){
	console.log('on exit');	
});

console.log('event test');

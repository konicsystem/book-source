process.addListener('exit', function(){
	console.log('addListener exit');
});

console.log('event test');

create table saram (
id varchar(20),
name varchar(20),
age tinyint
);

insert into saram (id, name, age) 
values ('hong','gildong',33);
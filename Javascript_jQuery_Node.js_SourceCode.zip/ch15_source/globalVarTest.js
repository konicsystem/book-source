console.log('현재 실행되는 파일의 절대경로 : ' + __filename);
console.log('현재 실행되는 파일이 속해 있는 디렉토리 ' + __dirname);
var url = require('url');
console.log(url.format({protocol : 'http' ,host:'localhost',  pathname : '/test'}));
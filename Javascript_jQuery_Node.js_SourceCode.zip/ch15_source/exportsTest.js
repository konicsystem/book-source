var calc = require('./calc.js');

console.log('title : ' + calc.title);
console.log('10 + 10 = %d',calc.add(10,10));
console.log('10 - 10 = %d',calc.substract(10,10));
console.log('10 * 10 = %d',calc.multiply(10,10));
console.log('10 / 10 = %d',calc.devide(10,10));

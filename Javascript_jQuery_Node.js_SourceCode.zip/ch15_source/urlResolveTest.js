var url = require('url');
console.log(url.resolve('http://localhost','/test/aaa'));